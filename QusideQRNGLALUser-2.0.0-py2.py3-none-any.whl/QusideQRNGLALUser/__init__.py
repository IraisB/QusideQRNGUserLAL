def function_init():
    print('Successfully Imported Init.py')
